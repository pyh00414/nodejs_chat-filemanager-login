public class good{
	public statis void main(String args[]

